export default function registerAntibot(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
