export default function registerAntilink(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
