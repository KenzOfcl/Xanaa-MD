export default function registerAntidelete(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
