export default function registerViewone(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
