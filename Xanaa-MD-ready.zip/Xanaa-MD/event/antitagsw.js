export default function registerAntitagsw(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
