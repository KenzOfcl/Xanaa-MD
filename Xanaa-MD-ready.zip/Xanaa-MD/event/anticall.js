export default function registerAnticall(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
