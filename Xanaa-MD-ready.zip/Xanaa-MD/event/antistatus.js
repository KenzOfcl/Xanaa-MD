export default function registerAntistatus(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
