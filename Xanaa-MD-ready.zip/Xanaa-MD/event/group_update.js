export default function registerGroupupdate(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
