export default function registerGreettings(sock) {
  // Starter event: tambahkan listener Baileys di sini.
  return sock;
}
