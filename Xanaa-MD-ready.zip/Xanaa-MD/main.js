import makeWASocket, {
  Browsers,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import P from "pino";
import readline from "readline";
import fs from "fs";
import config from "./config.js";
import { handleCommand } from "./lib/handler.js";
import { initDB } from "./database/database.js";

const logger = P({ level: "silent" });

const ask = (question) =>
  new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim());
    });
  });

async function startBot() {
  await initDB();

  if (!fs.existsSync(config.sessionDir)) fs.mkdirSync(config.sessionDir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);

  const sock = makeWASocket({
    auth: state,
    logger,
    browser: Browsers.ubuntu(config.botName),
    printQRInTerminal: true,
    markOnlineOnConnect: false
  });

  sock.ev.on("creds.update", saveCreds);

  if (!state.creds.registered) {
    console.log("\n=== XANAA-MD PAIRING ===");
    console.log("Nomor WhatsApp harus memakai kode negara, tanpa +, spasi, atau tanda -.");
    const phone = await ask("Masukkan nomor WhatsApp: ");

    if (!/^\d{8,15}$/.test(phone)) {
      console.log("Nomor tidak valid.");
      process.exit(1);
    }

    try {
      // Beberapa rilis/fork Baileys mendukung custom pairing code.
      // Pada rilis yang hanya menerima nomor, WhatsApp akan membuat kode otomatis.
      const pair = await sock.requestPairingCode(phone, config.pairingCode);
      console.log(`\nPairing code: ${pair}`);
      console.log("Di WhatsApp: Perangkat tertaut -> Tautkan dengan nomor telepon.");
      console.log(`Branding pairing: ${config.pairingCode}`);
    } catch (err) {
      console.log("Gagal membuat pairing code:", err?.message || err);
      console.log("QR code tetap tersedia di terminal jika didukung.");
    }
  }

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      console.log(`\n✅ ${config.botName} terhubung.`);
      console.log(`👑 Owner: ${config.ownerName} (${config.ownerNumber})`);
    }

    if (connection === "close") {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const reconnect = code !== DisconnectReason.loggedOut;
      console.log("Koneksi tertutup:", code, "reconnect:", reconnect);
      if (reconnect) startBot();
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;

    for (const m of messages) {
      if (!m.message || m.key.fromMe) continue;
      try {
        await handleCommand(sock, m);
      } catch (err) {
        console.error("Command error:", err);
      }
    }
  });

  return sock;
}

startBot().catch(console.error);
