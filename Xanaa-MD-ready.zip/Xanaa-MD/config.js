export default {
  ownerName: "Kenzy Official",
  ownerNumber: "6289674116378",
  botName: "Xanaa-MD",
  prefix: ".",
  pairingCode: "XANABOTZ",
  sessionDir: "./session",
  databaseFile: "./database.json",
  maxStickerBytes: 2 * 1024 * 1024,
  antiLink: true,
  antiBadword: false
};
